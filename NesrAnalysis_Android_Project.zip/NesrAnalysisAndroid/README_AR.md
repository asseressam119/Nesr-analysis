# Nesr analysis — Android

هذا المشروع يضع ملف HTML داخل WebView Android ويضيف دعمًا حقيقيًا لـ `input type=file` عبر `WebChromeClient.onShowFileChooser`.

## البناء
1. افتح المجلد في Android Studio.
2. انتظر Gradle Sync.
3. Build > Build APK(s).
4. ثبّت APK الناتج.

الملف HTML موجود في `app/src/main/assets/index.html`.
